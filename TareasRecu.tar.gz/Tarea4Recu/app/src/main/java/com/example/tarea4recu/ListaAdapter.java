package com.example.tarea4recu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ListaAdapter extends RecyclerView.Adapter<ListaAdapter.ViewHolder> {

    private List<PlaceholderContent.ElementoLista> listaElementos;

    public ListaAdapter(List<PlaceholderContent.ElementoLista> listaElementos) {
        this.listaElementos = listaElementos;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_lista, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        PlaceholderContent.ElementoLista elemento = listaElementos.get(position);

        holder.nombreTextView.setText(elemento.getNombre());
        holder.descripcionTextView.setText(elemento.getDescripcion());
    }

    @Override
    public int getItemCount() {
        return listaElementos.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView nombreTextView;
        TextView descripcionTextView;

        public ViewHolder(View itemView) {
            super(itemView);
            nombreTextView = itemView.findViewById(R.id.usernameEditText);
            descripcionTextView = itemView.findViewById(R.id.passwordEditText);
        }
    }
}
