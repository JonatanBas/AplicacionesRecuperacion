package com.example.tarea4recu;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentContainerView;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        // Obtener referencia al FragmentContainerView
        FragmentContainerView fragmentContainer = findViewById(R.id.fragmentContainer);

        // Crear una instancia del fragmento de lista
        OtroFragmento fragmento = new OtroFragmento();
        // Obtener referencia al FragmentManager
        FragmentManager fragmentManager = getSupportFragmentManager();

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        // Crear una instancia de FragmentTransaction
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        // Realizar la transacción de fragmento
        fragmentTransaction.replace(R.id.fragmentContainer, fragmento);
        fragmentTransaction.commit();


        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                // Aquí puedes realizar la validación de las credenciales ingresadas
                if (isValidCredentials(username, password)) {
                    // Si las credenciales son válidas, puedes iniciar una nueva actividad o fragmento
                    // que muestre la lista de elementos
                    Intent intent = new Intent(MainActivity.this, ListaActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Credenciales inválidas", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean isValidCredentials(String username, String password) {
        // Aquí puedes implementar la lógica de validación de las credenciales ingresadas
        // y retornar true si son válidas, o false si no lo son
        return username.equals("usuario") && password.equals("contraseña");
    }
}
