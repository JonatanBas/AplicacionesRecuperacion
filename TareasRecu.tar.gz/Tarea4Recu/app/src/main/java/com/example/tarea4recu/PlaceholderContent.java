package com.example.tarea4recu;

// PlaceholderContent.java

import java.util.ArrayList;
import java.util.List;

public class PlaceholderContent {

    private static List<ElementoLista> listaElementos;

    public static List<ElementoLista> getListaElementos() {
        if (listaElementos == null) {
            listaElementos = new ArrayList<>();
            listaElementos.add(new ElementoLista("Elemento 1", "Descripción del elemento 1"));
            listaElementos.add(new ElementoLista("Elemento 2", "Descripción del elemento 2"));
            listaElementos.add(new ElementoLista("Elemento 3", "Descripción del elemento 3"));
            // Agrega más elementos según tus necesidades
        }
        return listaElementos;
    }

    public static class ElementoLista {
        private String nombre;
        private String descripcion;

        public ElementoLista(String nombre, String descripcion) {
            this.nombre = nombre;
            this.descripcion = descripcion;
        }

        public String getNombre() {
            return nombre;
        }

        public String getDescripcion() {
            return descripcion;
        }
    }
}
